# SULTAN AI 1.0 — Termux build guide

## 1. Termux setup (once)
```bash
termux-setup-storage
pkg update && pkg upgrade -y
pkg install openjdk-17 gradle aapt2 git unzip wget -y
```

## 2. Android SDK (platform 34)
`sdkmanager` is a Java tool, so it runs on ARM. Download "Command line tools only" (Linux) from
https://developer.android.com/studio#command-line-tools-only then:
```bash
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
unzip ~/storage/downloads/commandlinetools-linux-*.zip && mv cmdline-tools latest
export ANDROID_HOME=~/android-sdk
yes | ~/android-sdk/cmdline-tools/latest/bin/sdkmanager --licenses
~/android-sdk/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0"
```
The x86 binaries inside build-tools will not run on your phone; that is fine, build.sh points Gradle to Termux's own `aapt2`.

## 3. Build
```bash
cd ~/storage/downloads && unzip SultanAI.zip -d ~ && cd ~/SultanAI
./build.sh
```
First build downloads many dependencies and is slow (10-30 min). Needs ~3 GB RAM free; close other apps.

**APK:** `~/SultanAI/app/build/outputs/apk/debug/app-debug.apk` (also copied to Downloads/SultanAI.apk)

## 4. Install
Open Downloads → SultanAI.apk → allow "install unknown apps" → Install.
Or `termux-open app/build/outputs/apk/debug/app-debug.apk`.

## 5. First run
1. Allow microphone + notifications.
2. Home → Gemini Setup → paste API key (https://aistudio.google.com/apikey) → Connect.
3. For touch automation: Phone Automation → Accessibility Settings → SULTAN AI → ON.
   (Android 13+: App info → ⋮ → "Allow restricted settings" first.)

## If Termux build fails
Push this folder to GitHub; the included `.github/workflows/build.yml` builds the APK in the cloud (Actions → artifact).
Common Termux errors: out of memory (lower `-Xmx` in gradle.properties), aapt2 daemon failed (re-check `pkg install aapt2`),
SDK license error (rerun the licenses command).

## Security notes
API key: EncryptedSharedPreferences (Android Keystore). Production: keep the key on your server, authenticate users, rate-limit.
