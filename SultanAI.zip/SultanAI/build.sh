#!/data/data/com.termux/files/usr/bin/bash
# Termux build helper: ./build.sh
set -e
export JAVA_HOME="${JAVA_HOME:-$PREFIX/lib/jvm/java-17-openjdk}"
export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
echo "sdk.dir=$ANDROID_HOME" > local.properties
# Google's aapt2 is x86 only; use Termux's native ARM aapt2
gradle --no-daemon assembleDebug "-Pandroid.aapt2FromMavenOverride=$PREFIX/bin/aapt2" "$@"
APK=app/build/outputs/apk/debug/app-debug.apk
echo "APK ready: $PWD/$APK"
if [ -d "$HOME/storage/downloads" ]; then cp "$APK" "$HOME/storage/downloads/SultanAI.apk" && echo "Copied to Downloads/SultanAI.apk"; fi
