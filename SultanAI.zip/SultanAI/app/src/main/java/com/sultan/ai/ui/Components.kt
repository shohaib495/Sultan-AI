package com.sultan.ai.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun Orb(level: Float, active: Boolean, dp: Dp = 220.dp) {
    val t = rememberInfiniteTransition(label = "orb")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "rot")
    val pulse by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val lv by animateFloatAsState(if (active) level else 0f, label = "lv")
    Canvas(Modifier.size(dp)) {
        val c = center
        val r = this.size.minDimension / 2
        val glow = r * 0.9f * pulse * (1f + lv * 0.15f)
        drawCircle(Brush.radialGradient(listOf(Blue.copy(alpha = 0.85f), Blue.copy(alpha = 0.25f), Color.Transparent), center = c, radius = glow), radius = glow)
        val core = r * 0.42f * pulse * (1f + lv * 0.5f)
        drawCircle(Color.White.copy(alpha = 0.9f), radius = core * 0.3f)
        drawCircle(Blue, radius = core, style = Stroke(3.dp.toPx()))
        rotate(rot) {
            drawArc(Blue, 0f, 100f, false, Offset(c.x - r * 0.8f, c.y - r * 0.8f), Size(r * 1.6f, r * 1.6f), style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
            drawArc(Blue.copy(alpha = 0.6f), 180f, 60f, false, Offset(c.x - r * 0.8f, c.y - r * 0.8f), Size(r * 1.6f, r * 1.6f), style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
        }
        rotate(-rot * 1.5f) {
            drawArc(Color.White.copy(alpha = 0.7f), 40f, 70f, false, Offset(c.x - r * 0.62f, c.y - r * 0.62f), Size(r * 1.24f, r * 1.24f), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            drawArc(Blue, 220f, 90f, false, Offset(c.x - r * 0.62f, c.y - r * 0.62f), Size(r * 1.24f, r * 1.24f), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

@Composable
fun Waveform(level: Float, active: Boolean, modifier: Modifier = Modifier.fillMaxWidth().height(60.dp)) {
    val t = rememberInfiniteTransition(label = "wave")
    val ph by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "ph")
    Canvas(modifier) {
        val n = 40
        val gap = size.width / n
        for (i in 0 until n) {
            val base = if (active) 0.15f + level * 0.85f else 0.08f
            val h = size.height * base * (0.35f + 0.65f * abs(sin(ph + i * 0.45f)))
            val x = i * gap + gap / 2
            drawLine(Blue, Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2), strokeWidth = gap * 0.5f, cap = StrokeCap.Round)
        }
    }
}

@Composable
fun Logo(size: Int = 28) {
    Text("SULTAN AI", color = Blue, fontSize = size.sp, fontWeight = FontWeight.Bold, letterSpacing = (size / 4).sp)
}

@Composable
fun StatusChip(label: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 12.dp)) {
        Box(Modifier.size(9.dp).background(if (ok) Good else Bad, CircleShape))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 12.sp, color = Color.LightGray)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeatureCard(emoji: String, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Blue.copy(alpha = 0.4f))) {
        Column(Modifier.padding(14.dp)) {
            Text(emoji, fontSize = 26.sp)
            Text(title, color = Blue, fontWeight = FontWeight.Bold)
            Text(sub, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun ConfirmDialog(vm: SultanVM) {
    val p = vm.pending ?: return
    AlertDialog(
        onDismissRequest = { vm.deny() },
        containerColor = Panel,
        title = { Text("SULTAN ijazat maang raha hai") },
        text = { Column { Text(p.title, fontWeight = FontWeight.Bold, color = Blue); Spacer(Modifier.height(6.dp)); Text(p.detail) } },
        confirmButton = { Button(onClick = { vm.confirm() }) { Text("Haan, karo") } },
        dismissButton = { TextButton(onClick = { vm.deny() }) { Text("Nahi") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    vm: SultanVM, title: String, onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.notice) { vm.notice?.let { vm.notice = null; snack.showSnackbar(it) } }
    ConfirmDialog(vm)
    Scaffold(
        containerColor = Bg,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text(title, color = Blue, fontWeight = FontWeight.Bold) },
                navigationIcon = { if (onBack != null) TextButton(onClick = onBack) { Text("◀", color = Blue, fontSize = 18.sp) } },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        },
        content = content
    )
}

@Composable
fun rememberMicAction(action: () -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val current by rememberUpdatedState(action)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) current() }
    return {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) current()
        else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }
}

@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    return tick
}

fun readText(ctx: Context, uri: Uri, max: Int = 20000): String =
    runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(max) } }.getOrNull().orEmpty()

fun hasMic(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
