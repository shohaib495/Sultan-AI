package com.sultan.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.room.Room
import com.sultan.ai.data.AppDb
import com.sultan.ai.data.GeminiClient
import com.sultan.ai.data.SecureStore

class SultanApp : Application() {
    lateinit var store: SecureStore
    lateinit var db: AppDb
    lateinit var gemini: GeminiClient

    override fun onCreate() {
        super.onCreate()
        store = SecureStore(this)
        db = Room.databaseBuilder(this, AppDb::class.java, "sultan.db").build()
        gemini = GeminiClient(store)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH)
        )
    }
}
