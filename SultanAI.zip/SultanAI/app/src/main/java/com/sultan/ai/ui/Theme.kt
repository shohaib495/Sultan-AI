package com.sultan.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF00B4FF)
val DeepBlue = Color(0xFF0A3D62)
val Bg = Color.Black
val Panel = Color(0xFF0B1620)
val Good = Color(0xFF00E676)
val Bad = Color(0xFFFF5252)

@Composable
fun SultanTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, onPrimary = Color.Black, secondary = Blue,
            background = Bg, onBackground = Color.White,
            surface = Panel, onSurface = Color.White,
            surfaceVariant = Panel, onSurfaceVariant = Color(0xFFB0C4DE)
        ),
        content = content
    )
}
