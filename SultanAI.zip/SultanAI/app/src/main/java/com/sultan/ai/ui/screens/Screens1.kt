package com.sultan.ai.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sultan.ai.automation.SultanAccessibilityService
import com.sultan.ai.core.Lang
import com.sultan.ai.ui.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(next: () -> Unit) {
    LaunchedEffect(Unit) { delay(2200); next() }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Orb(0f, false)
            Spacer(Modifier.height(24.dp))
            Logo(34)
            Text("v1.0 · JARVIS-inspired AI companion", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun WelcomeScreen(vm: SultanVM, done: () -> Unit) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.store.welcomed = true; done()
    }
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Orb(0f, false, 160.dp)
        Spacer(Modifier.height(16.dp))
        Logo(26)
        Spacer(Modifier.height(12.dp))
        Text("Assalam-o-Alaikum! Main SULTAN hoon, aapka AI saathi. Main ek AI hoon, insaan nahi.",
            color = Color.White, fontSize = 16.sp)
        Spacer(Modifier.height(16.dp))
        Text("Shuru karne se pehle:\n\n🎤 Microphone: awaaz se baat karne ke liye\n🔔 Notifications: reminders ke liye\n🌐 Internet: Gemini AI ke liye\n\n" +
            "Phone automation (Accessibility) aap baad mein khud enable karenge, aur har action se pehle main poochunga.",
            color = Color.LightGray, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            launcher.launch(perms.toTypedArray())
        }, modifier = Modifier.fillMaxWidth()) { Text("Shuru karein") }
    }
}

@Composable
fun HomeScreen(vm: SultanVM, nav: NavController) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val a11y = remember(tick) { SultanAccessibilityService.enabled }
    val mic = remember(tick) { hasMic(ctx) }
    ScreenScaffold(vm, "SULTAN AI", actions = {
        TextButton(onClick = { nav.navigate("settings") }) { Text("⚙", color = Blue, fontSize = 22.sp) }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Orb(vm.level, vm.listening, 170.dp)
            Spacer(Modifier.height(8.dp))
            Text("Farmaiye, main kya kar sakta hoon?", color = Color.White)
            Spacer(Modifier.height(10.dp))
            Row { StatusChip("AI", vm.store.connected); StatusChip("Mic", mic); StatusChip("Automation", a11y); StatusChip(vm.lang.label, true) }
            Spacer(Modifier.height(14.dp))
            val cards = listOf(
                Triple("💬", "AI Chat", "chat"), Triple("🎙️", "Voice", "voice"),
                Triple("👨‍💻", "Coding", "coding"), Triple("📱", "Automation", "automation"),
                Triple("🧠", "Memory & Notes", "memory"), Triple("🔑", "Gemini Setup", "gemini"),
                Triple("⚙️", "Settings", "settings"), Triple("ℹ️", "About", "about")
            )
            cards.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (e, t, r) ->
                        FeatureCard(e, t, "", Modifier.weight(1f).padding(vertical = 5.dp)) { nav.navigate(r) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Try: \"open youtube\" · \"play Atif Aslam on youtube\" · \"calculate 25*4+10\" · \"weather in Karachi\" · " +
                "\"remind me in 10 minutes to call mom\" · \"note: milk lana\" · \"remember: mujhe chai pasand hai\"",
                color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun ChatScreen(vm: SultanVM, nav: NavController) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    val mic = rememberMicAction { vm.micOnce() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) input = "Is text ko ${vm.mode.lowercase()} ke hisab se process karo:\n\n" + readText(ctx, uri)
    }
    LaunchedEffect(vm.messages.size) { if (vm.messages.isNotEmpty()) list.animateScrollToItem(vm.messages.size - 1) }
    ScreenScaffold(vm, "AI Chat", onBack = { nav.popBackStack() }, actions = {
        TextButton(onClick = { vm.setAutoSpeak(!vm.autoSpeak) }) { Text(if (vm.autoSpeak) "🔊" else "🔇", fontSize = 20.sp) }
        TextButton(onClick = { vm.clearChat() }) { Text("🗑", fontSize = 20.sp) }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            LazyRow(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("Chat", "Study", "Translate", "Summarize", "Search")) { m ->
                    FilterChip(selected = vm.mode == m, onClick = { vm.mode = m }, label = { Text(m) })
                }
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 10.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (vm.messages.isEmpty()) item { Text("Assalam-o-Alaikum! Main SULTAN hoon. Kuch bhi poochiye ya command dijiye 🙂", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                items(vm.messages.toList()) { m ->
                    val user = m.role == "user"
                    Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
                        Box(Modifier.widthIn(max = 320.dp)
                            .background(if (user) DeepBlue else Panel, RoundedCornerShape(14.dp))
                            .border(1.dp, Blue.copy(alpha = if (user) 0.2f else 0.5f), RoundedCornerShape(14.dp))
                            .padding(10.dp)) { SelectionContainer { Text(m.text, color = Color.White) } }
                    }
                }
                if (vm.busy) item { Text("SULTAN soch raha hai…", color = Blue, fontSize = 13.sp) }
            }
            if (vm.partial.isNotEmpty()) Text("🎤 ${vm.partial}", color = Blue, modifier = Modifier.padding(horizontal = 12.dp))
            Waveform(vm.level, vm.listening, Modifier.fillMaxWidth().height(28.dp))
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { picker.launch(arrayOf("text/*")) }) { Text("📎", fontSize = 20.sp) }
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message likhein…") }, maxLines = 4)
                TextButton(onClick = mic) { Text(if (vm.listening) "🔴" else "🎤", fontSize = 22.sp) }
                Button(onClick = { vm.send(input); input = "" }, enabled = !vm.busy) { Text("➤") }
            }
        }
    }
}

@Composable
fun VoiceScreen(vm: SultanVM, nav: NavController) {
    val mic = rememberMicAction { vm.startConversation() }
    val state = when {
        vm.busy -> "Soch raha hoon…"
        vm.speaking -> "Bol raha hoon…"
        vm.listening -> "Sun raha hoon…"
        vm.conversation -> "Tayyar…"
        else -> "Mic dabayein aur baat shuru karein"
    }
    ScreenScaffold(vm, "Voice Assistant", onBack = { vm.stopConversation(); nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Orb(vm.level, vm.listening || vm.speaking, 240.dp)
            Spacer(Modifier.height(8.dp))
            Waveform(vm.level, vm.listening || vm.speaking)
            Text(state, color = Blue, fontWeight = FontWeight.Bold)
            if (vm.partial.isNotEmpty()) Text("“${vm.partial}”", color = Color.White)
            Spacer(Modifier.height(10.dp))
            vm.messages.lastOrNull { it.role == "model" }?.let {
                Text(it.text, color = Color.LightGray, fontSize = 14.sp, maxLines = 8)
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { if (vm.conversation) vm.stopConversation() else mic() },
                shape = CircleShape, modifier = Modifier.size(84.dp)) { Text(if (vm.conversation) "⏹" else "🎤", fontSize = 30.sp) }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(vm.wakeMode, { vm.wakeMode = it })
                Spacer(Modifier.width(8.dp))
                Text("Wake word: \"Hey Sultan\"", color = Color.White)
            }
            Text("Wake word sirf is screen khuli hone par kaam karta hai (background listening nahi, battery bachane ke liye).",
                color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(Lang.values().toList()) { l ->
                    FilterChip(selected = vm.lang == l, onClick = { vm.setLanguage(l) }, label = { Text(l.label) })
                }
            }
        }
    }
}
