package com.sultan.ai.ui.screens

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.provider.Settings
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.sultan.ai.automation.A11y
import com.sultan.ai.automation.AppLauncher
import com.sultan.ai.automation.SultanAccessibilityService
import com.sultan.ai.core.GEMINI_MODELS
import com.sultan.ai.core.Lang
import com.sultan.ai.personality.SystemPrompt
import com.sultan.ai.tools.Reminders
import com.sultan.ai.tools.YouTube
import com.sultan.ai.ui.*
import kotlinx.coroutines.launch
import java.net.URLEncoder

// ------------------------------------------------------------------ CODING
@Composable
fun CodingScreen(vm: SultanVM, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var language by remember { mutableStateOf("Python") }
    var mode by remember { mutableStateOf("Generate") }
    var prompt by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf(false) }

    val ext = when (language) { "Python" -> "py"; "HTML/CSS/JS" -> "html"; "Java" -> "java"; else -> "kt" }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray()) } }
            .onSuccess { vm.notice = "File save ho gayi ✅" }.onFailure { vm.notice = "Save fail: ${it.message}" }
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) code = readText(ctx, uri, 60000)
    }

    fun run() {
        val q = when (mode) {
            "Generate" -> "Write $language code for: $prompt\nReturn the complete code in one fenced block, then a short explanation."
            "Explain" -> "Explain this $language code step by step:\n```\n$code\n```\n$prompt"
            "Debug" -> "Find the bugs in this $language code and give the fixed full code.\nProblem/error: $prompt\n```\n$code\n```"
            else -> "Generate a complete $language project for: $prompt\nOutput every file as a line '### path/filename' followed by a fenced code block, then how to run it."
        }
        loading = true; result = ""
        scope.launch {
            result = vm.askRaw(q, SystemPrompt.CODING).getOrElse { "⚠️ ${it.message}" }
            loading = false
        }
    }

    ScreenScaffold(vm, "Coding Assistant", onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("Python", "HTML/CSS/JS", "Java", "Kotlin")) { l -> FilterChip(language == l, { language = l }, { Text(l) }) }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("Generate", "Explain", "Debug", "Project")) { m -> FilterChip(mode == m, { mode = m }, { Text(m) }) }
            }
            OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth(),
                label = { Text(if (mode == "Debug") "Error / masla" else "Kya banana hai / poochna hai?") })
            Text("Code Editor", color = Blue, fontWeight = FontWeight.Bold)
            OutlinedTextField(code, { code = it }, Modifier.fillMaxWidth().heightIn(min = 180.dp),
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color.White))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { run() }, enabled = !loading && (prompt.isNotBlank() || code.isNotBlank())) { Text(if (loading) "…" else "🤖 Run AI") }
                OutlinedButton(onClick = { opener.launch(arrayOf("text/*", "application/*")) }) { Text("📂") }
                OutlinedButton(onClick = { saver.launch("sultan_code.$ext") }, enabled = code.isNotBlank()) { Text("💾") }
                if (language == "HTML/CSS/JS") OutlinedButton(onClick = { preview = true }, enabled = code.isNotBlank()) { Text("▶ Preview") }
            }
            if (result.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        Regex("```[a-zA-Z+#]*\\n([\\s\\S]*?)```").find(result)?.let { code = it.groupValues[1].trimEnd() }
                            ?: run { vm.notice = "Result mein code block nahi mila" }
                    }) { Text("⬆ Code editor mein") }
                    OutlinedButton(onClick = { clip.setText(AnnotatedString(result)); vm.notice = "Copy ho gaya" }) { Text("📋 Copy") }
                }
                Surface(color = Panel, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, Blue.copy(alpha = 0.4f))) {
                    SelectionContainer { Text(result, Modifier.padding(10.dp), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color.White) }
                }
            }
        }
    }
    if (preview) AlertDialog(onDismissRequest = { preview = false }, containerColor = Panel,
        confirmButton = { TextButton(onClick = { preview = false }) { Text("Band") } },
        title = { Text("HTML Preview") },
        text = {
            AndroidView(factory = { c -> WebView(c).apply { settings.javaScriptEnabled = true
                loadDataWithBaseURL(null, code, "text/html", "utf-8", null) } },
                modifier = Modifier.fillMaxWidth().height(400.dp))
        })
}

// ------------------------------------------------------------------ AUTOMATION
@Composable
fun AutomationScreen(vm: SultanVM, nav: NavController) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val enabled = remember(tick) { SultanAccessibilityService.enabled }
    var appQ by remember { mutableStateOf("") }
    var yt by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var clickT by remember { mutableStateOf("") }
    var typeT by remember { mutableStateOf("") }
    val apps = remember { AppLauncher.installed(ctx) }
    val matches = remember(appQ) { if (appQ.isBlank()) emptyList() else apps.filter { it.label.contains(appQ, true) }.take(6) }

    ScreenScaffold(vm, "Phone Automation", onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(color = Panel, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, Blue.copy(alpha = 0.4f))) {
                Column(Modifier.padding(12.dp)) {
                    StatusChip(if (enabled) "Accessibility service ON" else "Accessibility service OFF", enabled)
                    Text("Har action se pehle aapse confirmation li jati hai aur action ke waqt toast dikhta hai. Koi hidden action nahi.",
                        color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                        Text("Accessibility Settings kholein")
                    }
                    Text("Settings → Installed apps → SULTAN AI → ON. (Android 13+ par agar blocked ho: App info → ⋮ → Allow restricted settings.)",
                        color = Color.Gray, fontSize = 11.sp)
                }
            }
            Text("📱 App kholein", color = Blue, fontWeight = FontWeight.Bold)
            OutlinedTextField(appQ, { appQ = it }, Modifier.fillMaxWidth(), label = { Text("App ka naam") }, singleLine = true)
            matches.forEach { app ->
                OutlinedButton(onClick = { vm.request("App kholna: ${app.label}", "${app.label} launch hogi.") {
                    if (AppLauncher.launch(ctx, app.pkg)) "📱 ${app.label} khul gayi" else "⚠️ nahi khul saki" } },
                    Modifier.fillMaxWidth()) { Text(app.label) }
            }
            Text("▶️ YouTube", color = Blue, fontWeight = FontWeight.Bold)
            OutlinedTextField(yt, { yt = it }, Modifier.fillMaxWidth(), label = { Text("Gana / video ka naam") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { vm.request("YouTube: \"$yt\"", "Search karke pehla video play hoga.") {
                    val id = runCatching { YouTube.firstVideoId(yt) }.getOrNull()
                    if (id != null) { AppLauncher.openYoutubeVideo(ctx, id); "▶️ Play ho raha hai" }
                    else { AppLauncher.openUrl(ctx, "https://www.youtube.com/results?search_query=" + URLEncoder.encode(yt, "UTF-8")); "Search results khol diye" } } },
                    enabled = yt.isNotBlank()) { Text("Play") }
                OutlinedButton(onClick = { vm.request("YouTube kholna", "YouTube app khulegi.") { AppLauncher.openYoutube(ctx); "YouTube khul gaya" } }) { Text("YouTube kholo") }
            }
            Text("🌐 Website", color = Blue, fontWeight = FontWeight.Bold)
            OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("example.com") }, singleLine = true)
            Button(onClick = { vm.request("Website kholna", url) { AppLauncher.openUrl(ctx, url.trim()); "🌐 Khul gayi" } }, enabled = url.isNotBlank()) { Text("Kholo") }
            Text("⚙️ Android Settings", color = Blue, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(AppLauncher.SETTINGS_KEYS) { k ->
                    AssistChip(onClick = { vm.request("Settings: $k", "$k settings khulengi.") {
                        if (AppLauncher.openSettings(ctx, k)) "⚙️ $k settings khul gayi" else "⚠️ nahi khul saki" } }, label = { Text(k) })
                }
            }
            Text("🤖 Touch automation (Accessibility)", color = Blue, fontWeight = FontWeight.Bold)
            val acts = listOf(
                "Back" to { s: SultanAccessibilityService -> s.global(AccessibilityService.GLOBAL_ACTION_BACK) },
                "Home" to { s: SultanAccessibilityService -> s.global(AccessibilityService.GLOBAL_ACTION_HOME) },
                "Recents" to { s: SultanAccessibilityService -> s.global(AccessibilityService.GLOBAL_ACTION_RECENTS) },
                "Notifications" to { s: SultanAccessibilityService -> s.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) },
                "Scroll neeche" to { s: SultanAccessibilityService -> s.scroll(true) },
                "Scroll upar" to { s: SultanAccessibilityService -> s.scroll(false) }
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(acts) { (label, f) ->
                    AssistChip(onClick = { vm.request("Accessibility: $label", "Screen par '$label' action hoga.") { A11y.run(label, f) } }, label = { Text(label) })
                }
            }
            OutlinedTextField(clickT, { clickT = it }, Modifier.fillMaxWidth(), label = { Text("Screen par is text wale button par tap") }, singleLine = true)
            Button(onClick = { vm.request("Tap: \"$clickT\"", "Current screen par '$clickT' likha element tap hoga.") { A11y.run("Tap '$clickT'") { it.clickText(clickT) } } },
                enabled = clickT.isNotBlank()) { Text("Tap karo") }
            OutlinedTextField(typeT, { typeT = it }, Modifier.fillMaxWidth(), label = { Text("Focused text box mein likhna") }, singleLine = true)
            Button(onClick = { vm.request("Text likhna", "Focused field mein '$typeT' likha jayega.") { A11y.run("Text likhna") { it.typeText(typeT) } } },
                enabled = typeT.isNotBlank()) { Text("Likho") }
        }
    }
}

// ------------------------------------------------------------------ SETTINGS
@Composable
fun SettingsScreen(vm: SultanVM, nav: NavController) {
    val ctx = LocalContext.current
    var rate by remember { mutableFloatStateOf(vm.store.rate) }
    ScreenScaffold(vm, "Settings", onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Zaban (voice + jawab)", color = Blue, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(Lang.values().toList()) { l -> FilterChip(vm.lang == l, { vm.setLanguage(l) }, { Text(l.label) }) }
            }
            Text("Sindhi: recognition/voice sirf tab chalegi jab aapke device ki Google app support kare.", color = Color.Gray, fontSize = 11.sp)
            Text("Awaaz ki raftaar: ${"%.1f".format(rate)}x", color = Color.White)
            Slider(rate, { rate = it; vm.setRate(it) }, valueRange = 0.6f..1.6f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(vm.autoSpeak, { vm.setAutoSpeak(it) }); Spacer(Modifier.width(8.dp)); Text("Chat ke jawab bol kar sunao", color = Color.White)
            }
            Button(onClick = { nav.navigate("gemini") }, Modifier.fillMaxWidth()) { Text("🔑 Gemini Configuration") }
            Button(onClick = { nav.navigate("memory") }, Modifier.fillMaxWidth()) { Text("🧠 Memory, Notes, Reminders") }
            Button(onClick = { nav.navigate("automation") }, Modifier.fillMaxWidth()) { Text("📱 Phone Automation") }
            Button(onClick = { nav.navigate("about") }, Modifier.fillMaxWidth()) { Text("ℹ️ About SULTAN") }
            OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                Modifier.fillMaxWidth()) { Text("🔋 Battery settings") }
        }
    }
}

// ------------------------------------------------------------------ GEMINI CONFIG
@Composable
fun GeminiConfigScreen(vm: SultanVM, nav: NavController) {
    var key by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    val saved = vm.store.apiKey != null
    ScreenScaffold(vm, "Gemini Configuration", onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusChip(vm.keyStatus, vm.store.connected)
                if (vm.cfgBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
            }
            if (saved) Text("🔒 Ek key encrypted storage mein saved hai.", color = Color.Gray, fontSize = 12.sp)
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API Key") }, singleLine = true,
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "🙈" else "👁") } })
            Text("Key free mein aistudio.google.com/apikey se milti hai.", color = Color.Gray, fontSize = 11.sp)
            Text("Model", color = Blue, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(GEMINI_MODELS) { m -> FilterChip(vm.model == m, { vm.setModel(m) }, { Text(m, fontSize = 12.sp) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { vm.connect(key); key = "" }, enabled = !vm.cfgBusy && key.isNotBlank()) { Text("Connect") }
                OutlinedButton(onClick = { vm.test(key) }, enabled = !vm.cfgBusy) { Text("Test") }
                OutlinedButton(onClick = { vm.disconnect(); key = "" }, enabled = saved) { Text("Disconnect") }
            }
            vm.keyError?.let { Text("❌ $it", color = Bad) }
            Text("Security: key Android Keystore-backed EncryptedSharedPreferences mein rehti hai, HTTP header mein jati hai, log nahi hoti. " +
                "Production app mein key kabhi app ke andar na rakhein; apna backend proxy banayein jo key rakhe aur users ko authenticate kare.",
                color = Color.Gray, fontSize = 11.sp)
        }
    }
}

// ------------------------------------------------------------------ MEMORY
@Composable
fun MemoryScreen(vm: SultanVM, nav: NavController) {
    var tab by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf("") }
    val mem by vm.memories.collectAsState(initial = emptyList())
    val notes by vm.notes.collectAsState(initial = emptyList())
    val rem by vm.reminders.collectAsState(initial = emptyList())
    ScreenScaffold(vm, "Memory & Notes", onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab, containerColor = Bg) {
                listOf("Memory", "Notes", "Reminders").forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
            }
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(),
                    label = { Text(when (tab) { 0 -> "Kya yaad rakhun?"; 1 -> "Naya note"; else -> "Reminder text" }) })
                if (tab == 2) OutlinedTextField(mins, { mins = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Kitne minute baad?") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        when (tab) { 0 -> vm.addMemory(text); 1 -> vm.addNote(text); else -> vm.addReminder(text, mins.toLongOrNull() ?: 0) }
                        text = ""; mins = ""
                    }, enabled = text.isNotBlank()) { Text("Add") }
                    if (tab == 0 && mem.isNotEmpty()) OutlinedButton(onClick = { vm.clearMemory() }) { Text("Sab hatao") }
                }
                when (tab) {
                    0 -> { if (mem.isEmpty()) Text("Koi memory nahi. Chat mein bolein: \"remember: ...\"", color = Color.Gray)
                        mem.forEach { m -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🧠 ${m.text}", Modifier.weight(1f), color = Color.White); TextButton(onClick = { vm.delMemory(m) }) { Text("✕") } } } }
                    1 -> { if (notes.isEmpty()) Text("Koi note nahi.", color = Color.Gray)
                        notes.forEach { n -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📝 ${n.body}", Modifier.weight(1f), color = Color.White); TextButton(onClick = { vm.delNote(n) }) { Text("✕") } } } }
                    else -> { if (rem.isEmpty()) Text("Koi reminder nahi.", color = Color.Gray)
                        rem.forEach { r -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⏰ ${Reminders.fmt(r.at)} — ${r.text}", Modifier.weight(1f), color = Color.White); TextButton(onClick = { vm.delReminder(r) }) { Text("✕") } } }
                        Text("Note: phone restart hone par reminders dobara schedule nahi hote.", color = Color.Gray, fontSize = 11.sp) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ ABOUT
@Composable
fun AboutScreen(vm: SultanVM, nav: NavController) {
    ScreenScaffold(vm, "About SULTAN", onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Orb(0f, false, 140.dp)
            Logo(24)
            Text("Version 1.0", color = Color.Gray)
            Text("SULTAN ek AI assistant hai (insaan nahi), Google Gemini par chalta hai.", color = Color.White)
            Text("Jo kaam karta hai: chat, voice (STT/TTS), app/URL/YouTube/settings kholna, accessibility actions, coding help, " +
                "calculator, notes, reminders, weather (Open-Meteo), web search (Gemini grounding), translation, summarization, memory.\n\n" +
                "Hudood:\n• Sindhi recognition/voice device par depend karti hai.\n• Wake word sirf Voice screen khuli hone par.\n" +
                "• YouTube 'play' search page se pehla video nikalta hai, YouTube badle to toot sakta hai.\n" +
                "• Male voice device ki installed voices par depend karti hai (warna low-pitch).\n• Reminders reboot par reset ho jate hain.",
                color = Color.LightGray, fontSize = 13.sp)
        }
    }
}
