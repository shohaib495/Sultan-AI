package com.sultan.ai.automation

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object AppLauncher {
    data class AppInfo(val label: String, val pkg: String)

    fun installed(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    fun find(ctx: Context, name: String): AppInfo? {
        val n = name.lowercase().trim()
        val all = installed(ctx)
        return all.firstOrNull { it.label.lowercase() == n }
            ?: all.firstOrNull { it.label.lowercase().contains(n) }
            ?: all.firstOrNull { it.label.length > 2 && n.contains(it.label.lowercase()) }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i); return true
    }

    fun openUrl(ctx: Context, url: String) {
        val u = if (url.startsWith("http")) url else "https://$url"
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openYoutubeVideo(ctx: Context, id: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$id")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            openUrl(ctx, "https://www.youtube.com/watch?v=$id")
        }
    }

    fun openYoutube(ctx: Context) {
        if (!launch(ctx, "com.google.android.youtube")) openUrl(ctx, "https://www.youtube.com")
    }

    val SETTINGS_KEYS = listOf("wifi", "bluetooth", "display", "sound", "battery", "location",
        "accessibility", "airplane", "storage", "apps", "settings")

    fun openSettings(ctx: Context, key: String): Boolean {
        val action = when (key) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }
        catch (e: Exception) { false }
    }
}
