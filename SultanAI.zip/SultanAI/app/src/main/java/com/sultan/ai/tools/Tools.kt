package com.sultan.ai.tools

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Net {
    val http = OkHttpClient()
    fun get(url: String): String {
        val req = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept-Language", "en-US,en;q=0.9").build()
        http.newCall(req).execute().use { if (!it.isSuccessful) throw IOException("HTTP ${it.code}"); return it.body?.string().orEmpty() }
    }
}

object TimeInfo {
    fun now(): String = SimpleDateFormat("EEEE, d MMMM yyyy — hh:mm a", Locale.ENGLISH).format(Date())
}

object Calculator {
    fun eval(expr: String): Double =
        P(expr.lowercase().replace(" ", "").replace("×", "*").replace("÷", "/")).parse()

    fun format(d: Double): String =
        if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString()
        else String.format(Locale.US, "%.8f", d).trimEnd('0').trimEnd('.')

    private class P(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i < s.length) error("Ghalat character '${s[i]}'"); return v }
        fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') { val op = s[i++]; val r = term(); v = if (op == '+') v + r else v - r }
            return v
        }
        fun term(): Double {
            var v = pow()
            while (peek() == '*' || peek() == '/' || peek() == '%') {
                val op = s[i++]; val r = pow()
                v = when (op) {
                    '*' -> v * r
                    '/' -> { if (r == 0.0) error("Zero se taqseem nahi ho sakti"); v / r }
                    else -> v % r
                }
            }
            return v
        }
        fun pow(): Double { val b = unary(); if (peek() == '^') { i++; return Math.pow(b, pow()) }; return b }
        fun unary(): Double {
            if (peek() == '-') { i++; return -unary() }
            if (peek() == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            if (peek() == '(') { i++; val v = expr(); if (peek() != ')') error("')' missing"); i++; return v }
            if (peek().isDigit() || peek() == '.') {
                val st = i; while (peek().isDigit() || peek() == '.') i++
                return s.substring(st, i).toDouble()
            }
            if (peek().isLetter()) {
                val st = i; while (peek().isLetter()) i++
                val n = s.substring(st, i)
                if (n == "pi") return Math.PI
                if (n == "e") return Math.E
                if (peek() != '(') error("Unknown '$n'")
                i++; val a = expr(); if (peek() != ')') error("')' missing"); i++
                return when (n) {
                    "sqrt" -> Math.sqrt(a); "sin" -> Math.sin(Math.toRadians(a)); "cos" -> Math.cos(Math.toRadians(a))
                    "tan" -> Math.tan(Math.toRadians(a)); "log" -> Math.log10(a); "ln" -> Math.log(a); "abs" -> Math.abs(a)
                    else -> error("Unknown function '$n'")
                }
            }
            error("Ghalat expression")
        }
    }
}

object Weather {
    suspend fun get(city: String): String = withContext(Dispatchers.IO) {
        val geo = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(city, "UTF-8")))
        val res = geo.optJSONArray("results") ?: throw IOException("Shehar nahi mila: $city")
        val o = res.getJSONObject(0)
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${o.getDouble("latitude")}&longitude=${o.getDouble("longitude")}" +
            "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code"
        val c = JSONObject(Net.get(url)).getJSONObject("current")
        val desc = when (c.getInt("weather_code")) {
            0 -> "saaf aasman ☀️"; 1, 2 -> "thora badal ⛅"; 3 -> "badal chhaye ☁️"
            45, 48 -> "dhund 🌫️"; in 51..67 -> "barish 🌧️"; in 71..77 -> "barf ❄️"
            in 80..82 -> "barish ke jhonke 🌦️"; in 95..99 -> "toofan ⛈️"; else -> "mixed"
        }
        "🌍 ${o.getString("name")}: ${c.getDouble("temperature_2m")}°C, $desc, nami ${c.getInt("relative_humidity_2m")}%, hawa ${c.getDouble("wind_speed_10m")} km/h"
    }
}

object YouTube {
    /** Scrapes the first videoId from the public search page (no API key). May break if YouTube changes its page. */
    suspend fun firstVideoId(q: String): String? = withContext(Dispatchers.IO) {
        val html = Net.get("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8"))
        Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)?.groupValues?.get(1)
    }
}

object Reminders {
    fun schedule(ctx: Context, id: Long, text: String, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, id.toInt(), text, PendingIntent.FLAG_UPDATE_CURRENT)!!)
    }

    fun cancel(ctx: Context, id: Int) {
        pi(ctx, id, "", PendingIntent.FLAG_NO_CREATE)?.let { ctx.getSystemService(AlarmManager::class.java).cancel(it) }
    }

    private fun pi(ctx: Context, id: Int, text: String, flag: Int): PendingIntent? =
        PendingIntent.getBroadcast(ctx, id, Intent(ctx, ReminderReceiver::class.java).putExtra("t", text).putExtra("id", id),
            flag or PendingIntent.FLAG_IMMUTABLE)

    fun fmt(at: Long): String = SimpleDateFormat("d MMM, hh:mm a", Locale.ENGLISH).format(Date(at))

    /** "remind me in 10 minutes to call mom" / "10 minute baad yaad dilao chai" -> (delayMillis, text) */
    fun parseDelay(t: String): Pair<Long, String>? {
        val m = Regex("(\\d+)\\s*(seconds?|secs?|minutes?|mins?|mint|minat|hours?|hrs?|ghanta|ghante|ghantay|days?|din)",
            RegexOption.IGNORE_CASE).find(t) ?: return null
        val n = m.groupValues[1].toLong()
        val u = m.groupValues[2].lowercase()
        val ms = when {
            u.startsWith("sec") -> n * 1000
            u.startsWith("min") -> n * 60_000
            u.startsWith("h") || u.startsWith("ghant") -> n * 3_600_000
            else -> n * 86_400_000
        }
        var what = t.replace(m.value, "")
        what = what.replace(Regex("\\b(remind me|remind|reminder|yaad dilao|yaad dila do|yaad dilana|in|me|baad|bad|after|to|ko|ke)\\b",
            RegexOption.IGNORE_CASE), "").replace(Regex("\\s+"), " ").trim()
        return ms to what.ifEmpty { "Reminder" }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val n = Notification.Builder(c, "reminders")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("SULTAN reminder ⏰")
            .setContentText(i.getStringExtra("t"))
            .setAutoCancel(true).build()
        c.getSystemService(NotificationManager::class.java).notify(i.getIntExtra("id", 0), n)
    }
}
