package com.sultan.ai.ui

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sultan.ai.SultanApp
import com.sultan.ai.automation.A11y
import com.sultan.ai.automation.AppLauncher
import com.sultan.ai.core.Lang
import com.sultan.ai.core.Msg
import com.sultan.ai.data.Memory
import com.sultan.ai.data.Note
import com.sultan.ai.data.Reminder
import com.sultan.ai.personality.SystemPrompt
import com.sultan.ai.tools.*
import com.sultan.ai.voice.Recognizer
import com.sultan.ai.voice.Speaker
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.net.URLEncoder

class SultanVM(app: Application) : AndroidViewModel(app), Recognizer.Callback {
    private val a = app as SultanApp
    private val ctx: Context get() = getApplication()
    val store = a.store

    data class Pending(val title: String, val detail: String, val run: suspend () -> String)

    // chat / voice state
    val messages = mutableStateListOf<Msg>()
    var busy by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var speaking by mutableStateOf(false)
    var level by mutableStateOf(0f)
    var partial by mutableStateOf("")
    var conversation by mutableStateOf(false)
    var wakeMode by mutableStateOf(false)
    var mode by mutableStateOf("Chat")
    var lang by mutableStateOf(store.lang)
    var autoSpeak by mutableStateOf(store.autoSpeak)
    var pending by mutableStateOf<Pending?>(null)
    var notice by mutableStateOf<String?>(null)
    private var awake = false

    // gemini config state
    var keyStatus by mutableStateOf(if (store.connected) "Connected ✅" else "Disconnected")
    var keyError by mutableStateOf<String?>(null)
    var cfgBusy by mutableStateOf(false)
    var model by mutableStateOf(store.model)

    // db flows
    val memories = a.db.memory().all()
    val notes = a.db.notes().all()
    val reminders = a.db.reminders().all()

    private val speaker = Speaker(app) {
        speaking = false
        if (conversation) listenSoon()
    }.also { it.rate = store.rate }
    private val rec = Recognizer(app, this)

    // ---------------- Gemini configuration ----------------
    fun connect(key: String) = cfg(key, save = true)
    fun test(key: String) = cfg(key.ifBlank { store.apiKey.orEmpty() }, save = false)

    private fun cfg(key: String, save: Boolean) {
        if (key.isBlank()) { keyError = "Pehle API key dalein."; keyStatus = "Disconnected"; return }
        viewModelScope.launch {
            cfgBusy = true; keyError = null; keyStatus = "Testing…"
            val r = a.gemini.ping(key, model)
            if (r.isSuccess) {
                if (save) { store.apiKey = key; store.connected = true }
                keyStatus = if (save) "Connected ✅" else "Test OK ✅ (key save nahi hui)"
                if (!save && store.connected) keyStatus = "Connected ✅ (test OK)"
            } else {
                keyError = r.exceptionOrNull()?.message
                keyStatus = if (store.connected && !save) "Connected, lekin test fail ❌" else "Failed ❌"
            }
            cfgBusy = false
        }
    }

    fun disconnect() { store.apiKey = null; store.connected = false; keyError = null; keyStatus = "Disconnected" }
    fun setModel(m: String) { model = m; store.model = m }

    // ---------------- settings ----------------
    fun setLanguage(l: Lang) { lang = l; store.lang = l }
    fun setRate(r: Float) { store.rate = r; speaker.rate = r }
    fun setAutoSpeak(v: Boolean) { autoSpeak = v; store.autoSpeak = v }

    // ---------------- chat ----------------
    fun send(raw: String, spoken: Boolean = false) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        messages += Msg("user", text)
        busy = true
        viewModelScope.launch {
            val reply = try { route(text) } catch (e: Exception) { "⚠️ ${e.message}" }
            messages += Msg("model", reply)
            busy = false
            if (spoken || conversation || autoSpeak) say(reply)
        }
    }

    suspend fun askRaw(prompt: String, system: String) =
        a.gemini.generate(listOf(Msg("user", prompt)), system)

    private fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE)

    private fun calc(s: String) = runCatching { "🧮 $s = ${Calculator.format(Calculator.eval(s))}" }
        .getOrElse { "⚠️ Calculator: ${it.message}" }

    private suspend fun route(text: String): String {
        val l = text.lowercase().trim()
        val c = ctx

        rx("^(?:calc|calculate|hisab|hisaab|solve)\\s*:?\\s*(.+)$").find(l)?.let { return calc(it.groupValues[1]) }
        if (Regex("^[0-9\\s+\\-*/().^%]+$").matches(l) && l.any { it in "+-*/^%" }) return calc(l)

        rx("^(?:remember|yaad rakho|yaad rakhna)\\s*:?\\s*(.+)$").find(text.trim())?.let {
            a.db.memory().add(Memory(text = it.groupValues[1].trim()))
            return "🧠 Yaad rakh liya: ${it.groupValues[1].trim()} (Memory screen se hata sakte hain)"
        }
        rx("^note\\s*(?:likho|karo)?\\s*[:\\-]?\\s*(.+)$").find(text.trim())?.let {
            val b = it.groupValues[1].trim()
            a.db.notes().add(Note(title = b.take(30), body = b))
            return "📝 Note save ho gaya."
        }
        if (l.startsWith("remind") || l.contains("yaad dila")) {
            val (d, what) = Reminders.parseDelay(text)
                ?: return "⏰ Waqt batayein, jaise: 'remind me in 10 minutes to call mom'"
            val at = System.currentTimeMillis() + d
            val id = a.db.reminders().add(Reminder(text = what, at = at))
            Reminders.schedule(c, id, what, at)
            return "⏰ Theek hai! ${Reminders.fmt(at)} par yaad dilaunga: $what"
        }
        if (l.length < 30 && Regex("\\b(time|date|waqt|tarikh|baje)\\b").containsMatchIn(l)) return "🕒 ${TimeInfo.now()}"

        if (l.contains("weather") || l.contains("mausam")) {
            val city = l.replace(Regex("\\b(weather|mausam|in|of|for|ka|ki|ke|kaisa|hai|today|aaj|batao|bata|do|what|is|the|how|tell|me)\\b"), "")
                .replace(Regex("\\s+"), " ").trim()
                .ifEmpty { store.city ?: return "🌤️ Kis shehar ka mausam? Jaise: 'weather in Karachi'" }
            val r = Weather.get(city)
            store.city = city
            return r
        }

        if (l.contains("youtube")) {
            val q = l.replace(Regex("\\b(youtube|play|chalao|chala do|chalado|bajao|baja do|par|pe|on|search|open|kholo|khol do|karo|song|gana|video|ka|ki|ko|me|mein)\\b"), "")
                .replace(Regex("\\s+"), " ").trim()
            if (q.isEmpty()) {
                request("YouTube kholna", "YouTube app khuli jayegi.") { AppLauncher.openYoutube(c); "▶️ YouTube khul gaya" }
                return "YouTube kholne ke liye aapki ijazat chahiye. Confirm karein."
            }
            request("YouTube: \"$q\"", "YouTube par '$q' search karke pehla video play kiya jayega.") {
                val id = runCatching { YouTube.firstVideoId(q) }.getOrNull()
                if (id != null) { AppLauncher.openYoutubeVideo(c, id); "▶️ '$q' YouTube par chal raha hai" }
                else {
                    AppLauncher.openUrl(c, "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8"))
                    "Seedha video nahi mila, search results khol diye."
                }
            }
            return "YouTube par '$q' chalane ke liye aapki ijazat chahiye. Confirm karein."
        }

        val sKey = AppLauncher.SETTINGS_KEYS.firstOrNull { l.contains(it) }
        if (sKey != null && l.length < 50 && Regex("\\b(open|kholo|khol|setting|settings|navigate|jao)\\b").containsMatchIn(l)) {
            request("Android Settings: $sKey", "Phone ki $sKey settings khuli jayengi.") {
                if (AppLauncher.openSettings(c, sKey)) "⚙️ $sKey settings khul gayi" else "⚠️ Settings nahi khul saki"
            }
            return "$sKey settings kholne ke liye ijazat chahiye. Confirm karein."
        }

        val m = rx("^(?:open|launch|start|kholo)\\s+(.+)$").find(text.trim())
            ?: rx("^(.+?)\\s+(?:kholo|khol do|open karo|open kro|khol dein)$").find(text.trim())
        if (m != null) {
            val target = m.groupValues[1].trim()
            if (target.contains('.') && !target.contains(' ')) {
                request("Website kholna", target) { AppLauncher.openUrl(c, target); "🌐 $target khul gaya" }
                return "$target kholne ke liye ijazat chahiye. Confirm karein."
            }
            val app = AppLauncher.find(c, target) ?: return "📱 '$target' naam ki app nahi mili."
            request("App kholna: ${app.label}", "${app.label} app launch hogi.") {
                if (AppLauncher.launch(c, app.pkg)) "📱 ${app.label} khul gayi" else "⚠️ ${app.label} nahi khul saki"
            }
            return "${app.label} kholne ke liye ijazat chahiye. Confirm karein."
        }

        val search = mode == "Search" || rx("^(?:search|google|talash|dhundo|dhoondo)\\b").containsMatchIn(l)
        return ai(search)
    }

    private suspend fun ai(search: Boolean): String {
        val mems = a.db.memory().all().first().map { it.text }
        val hist = messages.takeLast(20).dropWhile { it.role != "user" }
        return a.gemini.generate(hist, SystemPrompt.build(lang, mems, if (search) "Search" else mode), search)
            .getOrElse { "⚠️ ${it.message}" }
    }

    // ---------------- permission-gated actions ----------------
    fun request(title: String, detail: String, run: suspend () -> String) { pending = Pending(title, detail, run) }

    fun confirm() {
        val p = pending ?: return
        pending = null
        viewModelScope.launch {
            val r = try { p.run() } catch (e: Exception) { "⚠️ ${e.message}" }
            messages += Msg("model", r)
            notice = r
            if (conversation) say(r)
        }
    }

    fun deny() {
        pending = null
        messages += Msg("model", "Theek hai, cancel kar diya ✅")
        if (conversation) listenSoon()
    }

    // ---------------- voice ----------------
    private fun say(text: String) {
        speaking = true
        val w = speaker.say(text, lang)
        if (w != null) {
            notice = w
            if (w.startsWith("⚠️")) { speaking = false; if (conversation) listenSoon() }
        }
    }

    fun startConversation() { conversation = true; awake = false; listenNow() }
    fun stopConversation() {
        conversation = false; rec.stop(); speaker.stop()
        listening = false; speaking = false; partial = ""; level = 0f
    }
    fun micOnce() { conversation = false; listenNow() }

    private fun listenSoon() {
        viewModelScope.launch {
            delay(450)
            if (conversation && pending == null && !busy && !speaking) listenNow()
        }
    }

    private fun listenNow() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            notice = "Microphone permission dein."; conversation = false; return
        }
        partial = ""
        rec.start(lang)
    }

    override fun onPartial(t: String) { partial = t }
    override fun onLevel(l: Float) { level = l }
    override fun onState(listening: Boolean) { this.listening = listening }

    override fun onFinal(t: String) {
        partial = ""
        var text = t
        if (wakeMode && conversation && !awake) {
            val w = Regex("(hey|hi|ok|okay)?\\s*(sultan|sultaan|سلطان)", RegexOption.IGNORE_CASE).find(text)
            if (w == null) { listenSoon(); return }          // ignore speech without the wake word
            text = text.substring(w.range.last + 1).trim(' ', ',', '.')
            if (text.isEmpty()) { awake = true; messages += Msg("model", "Ji, farmaiye?"); say("Ji, farmaiye?"); return }
        }
        awake = false
        send(text, spoken = conversation)
    }

    override fun onError(msg: String, recoverable: Boolean) {
        listening = false
        if (recoverable && conversation) listenSoon()
        else { notice = msg; if (!recoverable) conversation = false }
    }

    // ---------------- notes / memory / reminders ----------------
    fun addMemory(t: String) = viewModelScope.launch { if (t.isNotBlank()) a.db.memory().add(Memory(text = t.trim())) }
    fun delMemory(m: Memory) = viewModelScope.launch { a.db.memory().del(m) }
    fun clearMemory() = viewModelScope.launch { a.db.memory().clear() }
    fun addNote(t: String) = viewModelScope.launch {
        if (t.isNotBlank()) a.db.notes().add(Note(title = t.lines().first().take(30), body = t.trim()))
    }
    fun delNote(n: Note) = viewModelScope.launch { a.db.notes().del(n) }
    fun addReminder(text: String, minutes: Long) = viewModelScope.launch {
        if (text.isBlank() || minutes <= 0) return@launch
        val at = System.currentTimeMillis() + minutes * 60_000
        val id = a.db.reminders().add(Reminder(text = text.trim(), at = at))
        Reminders.schedule(ctx, id, text.trim(), at)
    }
    fun delReminder(r: Reminder) = viewModelScope.launch { Reminders.cancel(ctx, r.id.toInt()); a.db.reminders().del(r) }

    fun clearChat() { messages.clear() }

    override fun onCleared() { speaker.shutdown(); rec.stop() }
}
