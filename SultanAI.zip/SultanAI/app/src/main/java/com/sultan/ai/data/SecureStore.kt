package com.sultan.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.sultan.ai.core.Lang

/** Everything is stored in EncryptedSharedPreferences (AES-256, key kept in Android Keystore). */
class SecureStore(ctx: Context) {
    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        ctx, "sultan_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String?
        get() = prefs.getString("api_key", null)
        set(v) { prefs.edit().apply { if (v == null) remove("api_key") else putString("api_key", v.trim()) }.apply() }

    var model: String
        get() = prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { prefs.edit().putString("model", v).apply() }

    var connected: Boolean
        get() = prefs.getBoolean("connected", false)
        set(v) { prefs.edit().putBoolean("connected", v).apply() }

    var lang: Lang
        get() = runCatching { Lang.valueOf(prefs.getString("lang", "ROMAN")!!) }.getOrDefault(Lang.ROMAN)
        set(v) { prefs.edit().putString("lang", v.name).apply() }

    var rate: Float
        get() = prefs.getFloat("rate", 1.0f)
        set(v) { prefs.edit().putFloat("rate", v).apply() }

    var autoSpeak: Boolean
        get() = prefs.getBoolean("auto_speak", false)
        set(v) { prefs.edit().putBoolean("auto_speak", v).apply() }

    var welcomed: Boolean
        get() = prefs.getBoolean("welcomed", false)
        set(v) { prefs.edit().putBoolean("welcomed", v).apply() }

    var city: String?
        get() = prefs.getString("city", null)
        set(v) { prefs.edit().putString("city", v).apply() }
}
