package com.sultan.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Does nothing on its own. It only executes actions that the app requested AFTER the user tapped
 * "Haan, karo" in the confirmation dialog. Every action also shows a visible toast.
 */
class SultanAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: SultanAccessibilityService? = null
        val enabled: Boolean get() = instance != null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    fun announce(msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
        while (q.isNotEmpty()) {
            val n = q.removeFirst()
            if (n.isScrollable) {
                return n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
}

object A11y {
    fun run(label: String, f: (SultanAccessibilityService) -> Boolean): String {
        val s = SultanAccessibilityService.instance
            ?: return "⚠️ Accessibility service on nahi hai. Automation screen se enable karein."
        s.announce("SULTAN: $label")
        return if (f(s)) "✅ $label ho gaya" else "⚠️ $label nahi ho saka (screen par element nahi mila)"
    }
}
