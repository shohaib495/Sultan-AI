package com.sultan.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.sultan.ai.core.Lang

class Recognizer(private val ctx: Context, private val cb: Callback) {
    interface Callback {
        fun onPartial(t: String)
        fun onFinal(t: String)
        fun onError(msg: String, recoverable: Boolean)
        fun onLevel(l: Float)
        fun onState(listening: Boolean)
    }

    private var sr: SpeechRecognizer? = null

    fun start(lang: Lang) {
        stop()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            cb.onError("Speech recognition available nahi. Google app / Speech Services install karein.", false); return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { cb.onState(true) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { cb.onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { cb.onLevel(0f) }
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { cb.onPartial(it) }
            }
            override fun onResults(b: Bundle?) {
                cb.onState(false)
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isBlank()) cb.onError("Kuch suna nahi", true) else cb.onFinal(t)
            }
            override fun onError(code: Int) {
                cb.onState(false); cb.onLevel(0f)
                when (code) {
                    6, 7, 5, 8 -> cb.onError("Awaaz samajh nahi aayi", true)             // timeout, no match, client, busy
                    9 -> cb.onError("Microphone permission chahiye", false)
                    12, 13 -> cb.onError("${lang.label} recognition is device par supported nahi. Doosri language chunein.", false)
                    1, 2, 4 -> cb.onError("Speech service ke liye internet/Google service check karein", false)
                    else -> cb.onError("Speech error ($code)", false)
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.tag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(i)
    }

    fun stop() {
        sr?.destroy(); sr = null
        cb.onState(false); cb.onLevel(0f)
    }
}
