package com.sultan.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.sultan.ai.core.Lang
import java.util.Locale

class Speaker(ctx: Context, private val onDone: () -> Unit) {
    private var tts: TextToSpeech? = null
    private var ready = false
    var rate = 1.0f
    private val main = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { main.post { onDone() } }
                @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post { onDone() } }
            })
        }
    }

    /** Returns a warning string if it could not speak in the requested language. */
    fun say(text: String, lang: Lang): String? {
        val t = tts ?: return "⚠️ TTS engine nahi mila"
        if (!ready) return "⚠️ TTS abhi ready nahi"
        val wanted = Locale.forLanguageTag(lang.tag)
        val latin = lang == Lang.ENGLISH || lang == Lang.ROMAN
        var warn: String? = null
        if (t.isLanguageAvailable(wanted) >= TextToSpeech.LANG_AVAILABLE) {
            t.language = wanted
        } else if (latin) {
            t.language = Locale.ENGLISH
            warn = "${lang.label} voice nahi mili, English voice use hui"
        } else {
            return "⚠️ ${lang.label} ki TTS voice is device par install nahi (Settings → Text-to-speech se voice data download karein). Jawab sirf screen par hai."
        }
        pickMale(t)
        t.setPitch(0.8f)           // deeper pitch as a fallback for a male-sounding voice
        t.setSpeechRate(rate)
        t.speak(clean(text), TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        return warn
    }

    private fun pickMale(t: TextToSpeech) {
        val lang = t.language?.language ?: return
        val voices = t.voices?.filter { it.locale.language == lang && !it.isNetworkConnectionRequired } ?: return
        val maleCodes = listOf("-iom-", "-iol-", "-tpd-", "-ahp-", "-sfg-")   // common Google male voice ids (device dependent)
        val v = voices.firstOrNull { it.name.contains("male", true) && !it.name.contains("female", true) }
            ?: voices.firstOrNull { v -> maleCodes.any { v.name.contains(it) } }
        if (v != null) t.voice = v
    }

    private fun clean(s: String) = s
        .replace(Regex("```[\\s\\S]*?```"), " code screen par maujood hai. ")
        .replace(Regex("[*#`_>]"), "")
        .replace(Regex("https?://\\S+"), "link")

    fun stop() { tts?.stop() }
    fun shutdown() { tts?.stop(); tts?.shutdown() }
}
