package com.sultan.ai.core

enum class Lang(val label: String, val tag: String, val promptName: String) {
    ENGLISH("English", "en-US", "English"),
    URDU("اردو", "ur-PK", "Urdu (Arabic script)"),
    ROMAN("Roman Urdu", "en-IN", "Roman Urdu (Urdu written in Latin letters)"),
    SINDHI("سنڌي", "sd-PK", "Sindhi (Arabic script)")
}

/** role is "user" or "model" (Gemini naming). */
data class Msg(val role: String, val text: String)

val GEMINI_MODELS = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro", "gemini-2.0-flash")
