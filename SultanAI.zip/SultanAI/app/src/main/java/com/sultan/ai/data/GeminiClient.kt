package com.sultan.ai.data

import com.sultan.ai.core.Msg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class GeminiClient(private val store: SecureStore) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val base = "https://generativelanguage.googleapis.com/v1beta"
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    /** Sends a tiny real generateContent request: verifies both key and model. */
    suspend fun ping(key: String, model: String): Result<Unit> =
        generate(listOf(Msg("user", "Reply with the single word OK.")), "You are a connectivity test.", false, key, model)
            .map { }

    suspend fun generate(
        history: List<Msg>,
        system: String,
        useSearch: Boolean = false,
        key: String? = store.apiKey,
        model: String = store.model
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val k = key?.trim().orEmpty()
            if (k.isEmpty()) throw IOException("API key set nahi hai. Settings → Gemini Configuration mein key dalein.")
            val contents = JSONArray()
            history.forEach {
                contents.put(JSONObject().put("role", it.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text))))
            }
            val body = JSONObject()
                .put("contents", contents)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            if (useSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            val req = Request.Builder()
                .url("$base/models/$model:generateContent")
                .header("x-goog-api-key", k)           // key goes in a header, never in the URL/logs
                .post(body.toString().toRequestBody(jsonType))
                .build()
            http.newCall(req).execute().use { r ->
                val s = r.body?.string().orEmpty()
                if (!r.isSuccessful) throw IOException(errorText(r.code, s))
                parse(s)
            }
        }.recoverCatching { e ->
            throw if (e is java.net.UnknownHostException || e is java.net.SocketTimeoutException)
                IOException("Internet connection check karein.") else e
        }
    }

    private fun parse(s: String): String {
        val cand = JSONObject(s).optJSONArray("candidates")?.optJSONObject(0)
        val parts = cand?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        if (sb.isBlank()) throw IOException("Khali jawab aaya (shayad safety filter ya model issue).")
        return sb.toString().trim()
    }

    private fun errorText(code: Int, body: String?): String {
        val msg = runCatching { JSONObject(body ?: "").getJSONObject("error").getString("message") }.getOrNull()
        val hint = when (code) {
            400 -> "Request/API key ghalat ho sakti hai"
            401, 403 -> "API key invalid ya permission nahi"
            404 -> "Model nahi mila, doosra model chunein"
            429 -> "Quota/rate limit khatam, thori der baad try karein"
            in 500..599 -> "Google server issue"
            else -> "Error"
        }
        return "$hint (HTTP $code)" + (msg?.let { ": ${it.take(160)}" } ?: "")
    }
}
