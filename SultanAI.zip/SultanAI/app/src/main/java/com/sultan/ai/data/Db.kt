package com.sultan.ai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Note(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val body: String, val ts: Long = System.currentTimeMillis())
@Entity data class Reminder(@PrimaryKey(autoGenerate = true) val id: Long = 0, val text: String, val at: Long)
@Entity data class Memory(@PrimaryKey(autoGenerate = true) val id: Long = 0, val text: String)

@Dao interface NoteDao {
    @Query("SELECT * FROM Note ORDER BY ts DESC") fun all(): Flow<List<Note>>
    @Insert suspend fun add(n: Note): Long
    @Delete suspend fun del(n: Note)
}
@Dao interface ReminderDao {
    @Query("SELECT * FROM Reminder ORDER BY at ASC") fun all(): Flow<List<Reminder>>
    @Insert suspend fun add(r: Reminder): Long
    @Delete suspend fun del(r: Reminder)
}
@Dao interface MemoryDao {
    @Query("SELECT * FROM Memory ORDER BY id DESC") fun all(): Flow<List<Memory>>
    @Insert suspend fun add(m: Memory): Long
    @Delete suspend fun del(m: Memory)
    @Query("DELETE FROM Memory") suspend fun clear()
}

@Database(entities = [Note::class, Reminder::class, Memory::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun notes(): NoteDao
    abstract fun reminders(): ReminderDao
    abstract fun memory(): MemoryDao
}
