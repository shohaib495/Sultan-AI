package com.sultan.ai.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sultan.ai.ui.screens.*

@Composable
fun NavGraph(vm: SultanVM) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen {
                nav.navigate(if (vm.store.welcomed) "home" else "welcome") { popUpTo("splash") { inclusive = true } }
            }
        }
        composable("welcome") {
            WelcomeScreen(vm) { nav.navigate("home") { popUpTo("welcome") { inclusive = true } } }
        }
        composable("home") { HomeScreen(vm, nav) }
        composable("chat") { ChatScreen(vm, nav) }
        composable("voice") { VoiceScreen(vm, nav) }
        composable("coding") { CodingScreen(vm, nav) }
        composable("automation") { AutomationScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
        composable("gemini") { GeminiConfigScreen(vm, nav) }
        composable("memory") { MemoryScreen(vm, nav) }
        composable("about") { AboutScreen(vm, nav) }
    }
}
