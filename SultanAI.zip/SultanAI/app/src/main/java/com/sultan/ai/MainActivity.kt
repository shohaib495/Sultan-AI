package com.sultan.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sultan.ai.ui.NavGraph
import com.sultan.ai.ui.SultanTheme
import com.sultan.ai.ui.SultanVM

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SultanTheme {
                val vm: SultanVM = viewModel()
                NavGraph(vm)
            }
        }
    }
}
